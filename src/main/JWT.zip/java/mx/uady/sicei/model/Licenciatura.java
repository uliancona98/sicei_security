package mx.uady.sicei.model;

public enum Licenciatura {
    LIS,
    LIC,
    LCC
}