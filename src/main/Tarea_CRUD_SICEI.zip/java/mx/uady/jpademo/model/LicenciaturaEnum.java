package mx.uady.jpademo.model;

public enum LicenciaturaEnum {
    LIS,
    LIC,
    LCC
}